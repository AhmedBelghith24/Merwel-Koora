import React from 'react'

function SignOutLink() {
  return <div>SignOutLink</div>
}

export default SignOutLink

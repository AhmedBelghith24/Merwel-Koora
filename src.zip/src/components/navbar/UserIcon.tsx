import React from 'react'

function UserIcon() {
  return <div>UserIcon</div>
}

export default UserIcon

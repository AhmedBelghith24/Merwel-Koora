import React from 'react'

function FavoritesPage() {
  return <div>FavoritesPage</div>
}

export default FavoritesPage

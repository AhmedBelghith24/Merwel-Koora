import React from 'react'

function FavoriteToggleForm() {
  return <div>FavoriteToggleForm</div>
}

export default FavoriteToggleForm
